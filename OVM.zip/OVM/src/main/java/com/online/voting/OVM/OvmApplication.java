package com.online.voting.OVM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OvmApplication {

	public static void main(String[] args) {
		SpringApplication.run(OvmApplication.class, args);
	}

}
