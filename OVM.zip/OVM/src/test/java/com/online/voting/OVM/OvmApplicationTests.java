package com.online.voting.OVM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OvmApplicationTests {

	@Test
	void contextLoads() {
	}

}
